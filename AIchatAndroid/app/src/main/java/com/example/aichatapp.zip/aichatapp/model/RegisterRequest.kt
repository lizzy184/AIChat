package com.example.aichatapp.model

data class RegisterRequest (

    val username:String
)
